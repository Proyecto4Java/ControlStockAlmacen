/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author Usuario
 */
public class Producto {
    private int prod_id;
    private String prod_nom;
    private String prod_serie;
    private int categoria_id;
    

    public Producto() {
    }

    public Producto(int prod_id, String prod_nom, String prod_serie, int categoria_id) {
        this.prod_id = prod_id;
        this.prod_nom = prod_nom;
        this.prod_serie = prod_serie;
        this.categoria_id = categoria_id;
    }

    public Producto(String prod_nom, String prod_serie) {
        this.prod_nom = prod_nom;
        this.prod_serie = prod_serie;
    }

    public int getProd_id() {
        return prod_id;
    }

    public String getProd_nom() {
        return prod_nom;
    }

    public String getProd_serie() {
        return prod_serie;
    }

    public int getCategoria_id() {
        return categoria_id;
    }

    public void setProd_nom(String prod_nom) {
        this.prod_nom = prod_nom;
    }

    public void setProd_serie(String prod_serie) {
        this.prod_serie = prod_serie;
    }

}
