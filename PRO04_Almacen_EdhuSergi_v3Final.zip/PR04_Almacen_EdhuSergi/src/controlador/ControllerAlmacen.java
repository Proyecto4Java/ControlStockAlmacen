/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import model.Categoria;
import model.Conexion;
import model.Lugar;
import model.Persona;
import model.Producto;
import model.Stock;

/**
 *
 * @author Usuario
 */
public class ControllerAlmacen {

    public ControllerAlmacen() {
    }
    
        
    
    public static boolean isNumeric(String cadena){
	try {
		Integer.parseInt(cadena);
		return true;
	} catch (NumberFormatException nfe){
		return false;
	}
    }
    
    public DefaultTableModel mostrarProducto(){
        
        DefaultTableModel muestra = new DefaultTableModel();
        
        Conexion conecControl = new Conexion();
        Connection cn = conecControl.conectar();
        
        String sql = "SELECT tbl_producte.prod_id, tbl_producte.prod_nom, tbl_producte.prod_serie, tbl_categoria.categoria_nom, tbl_estoc.estoc_q_actual, tbl_estoc.estoc_q_min, tbl_estoc.estoc_q_max,  tbl_lloc.num_bloc, tbl_lloc.num_passadis, tbl_lloc.num_lleixa, tbl_estoc.estoc_id, tbl_lloc.lloc_id, tbl_producte.categoria_id FROM tbl_producte, tbl_categoria, tbl_estoc, tbl_lloc WHERE tbl_producte.categoria_id = tbl_categoria.categoria_id && tbl_estoc.prod_id = tbl_producte.prod_id && tbl_estoc.lloc_id = tbl_lloc.lloc_id";  

        Statement st = null;
        ResultSet rs = null;
        
        String vectorProducto[] = new String[13];
        String vectorProducto1[] = new String[13];
        
        vectorProducto1[0] = "ID";
        vectorProducto1[1] = "Nombre";
        vectorProducto1[2] = "Serie";
        vectorProducto1[3] = "Categoría";
        vectorProducto1[4] = "Stock";
        vectorProducto1[5] = "Stock MAX";
        vectorProducto1[6] = "Stock min";
        vectorProducto1[7] = "bloc";
        vectorProducto1[8] = "passadis";
        vectorProducto1[9] = "lleixa";
        vectorProducto1[10] = "estocid";
        vectorProducto1[11] = "llocid";
        vectorProducto1[12] = "catid";
          
        muestra = new DefaultTableModel(null,vectorProducto1);
        //String[] vectorProducto; 
        try {
            
            st = cn.createStatement();
            rs = st.executeQuery(sql);
            
            while (rs.next()) {
                
                vectorProducto[0] = String.valueOf(rs.getInt("prod_id"));
                vectorProducto[1] = rs.getString("prod_nom");
                vectorProducto[2] = rs.getString("prod_serie");
                vectorProducto[3] = rs.getString("categoria_nom");
                vectorProducto[4] = String.valueOf(rs.getInt("estoc_q_actual"));
                vectorProducto[5] = String.valueOf(rs.getInt("estoc_q_max"));
                vectorProducto[6] = String.valueOf(rs.getInt("estoc_q_min"));
                vectorProducto[7] = rs.getString("num_bloc");
                vectorProducto[8] = rs.getString("num_passadis");
                vectorProducto[9] = rs.getString("num_lleixa");
                vectorProducto[10] = String.valueOf(rs.getInt("estoc_id"));
                vectorProducto[11] = String.valueOf(rs.getInt("lloc_id"));
                vectorProducto[12] = String.valueOf(rs.getInt("categoria_id"));
                
              muestra.addRow(vectorProducto);
            }
      
        } catch (Exception e) {
        }
        
        return muestra;
    }
    
    public void ocultarColumna(int i, JTable jTable1){
        jTable1.getColumnModel().getColumn(i).setMaxWidth(0);

        jTable1.getColumnModel().getColumn(i).setMinWidth(0);

        jTable1.getColumnModel().getColumn(i).setPreferredWidth(0);
        
    }
    
    public DefaultTableModel mostrarLocalizacion(){
        DefaultTableModel muestraLoc = new DefaultTableModel();
        
        Conexion conecControl = new Conexion();
        Connection cn = conecControl.conectar();
        
        String sql = "SELECT tbl_producte.prod_id, tbl_producte.prod_nom, tbl_lloc.num_bloc, tbl_lloc.num_passadis, tbl_lloc.num_lleixa FROM tbl_producte, tbl_estoc, tbl_lloc WHERE tbl_estoc.prod_id = tbl_producte.prod_id && tbl_estoc.lloc_id = tbl_lloc.lloc_id";
        
        Statement st = null;
        ResultSet rs = null;
        
        String vectorProducto[] = new String[5];
        String vectorProducto1[] = new String[5];
        
        vectorProducto1[0] = "ID";
        vectorProducto1[1] = "Nombre";
        vectorProducto1[2] = "Bloque";
        vectorProducto1[3] = "Pasadizo";
        vectorProducto1[4] = "Estantería";
          
        muestraLoc = new DefaultTableModel(null,vectorProducto1);
        //String[] vectorProducto; 
        try {
            
            st = cn.createStatement();
            rs = st.executeQuery(sql);
            
            while (rs.next()) {
                
                vectorProducto[0] = String.valueOf(rs.getInt("prod_id"));
                vectorProducto[1] = rs.getString("prod_nom");
                vectorProducto[2] = rs.getString("num_bloc");
                vectorProducto[3] = rs.getString("num_passadis");
                vectorProducto[4] = rs.getString("num_lleixa");
                
              muestraLoc.addRow(vectorProducto);
            }
      
        } catch (Exception e) {
        }
        
        return muestraLoc;
    }
    
    public int login(String usuario, String clavedef){
        
        int resultado=0;
        
        Conexion conecControl = new Conexion();
        Connection cn = conecControl.conectar();
        
        String sql = "SELECT * FROM tbl_personas WHERE persona_usuario='"+usuario+"' && persona_password='"+clavedef+"'";
         
         try {
            // crear el statement
            Statement st = cn.createStatement();
            // lanzar la consulta
            ResultSet rs = st.executeQuery(sql);
            //lanza consulta con "executequery"
            if(rs.next()){
                resultado=1;
            }
         
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "UPPS! no se ha podido conectar a la base de datos");
        } finally {
             try {
                 cn.close();
             } catch (Exception e) {
                 JOptionPane.showMessageDialog(null, "UPPS! no se ha podido desconectar a la base de datos");
             }
        }
        return resultado; 
    }
    
    public void llenarCombo(JComboBox box){
        DefaultComboBoxModel value;
        
        Conexion conecControl = new Conexion();
        Connection cn = conecControl.conectar();

        String sql = "SELECT * FROM tbl_categoria";
        Statement st = null;
        ResultSet rs = null;

        try {
            st = cn.createStatement();
            rs = st.executeQuery(sql);

            value= new DefaultComboBoxModel();
            box.setModel(value);
            while (rs.next()) {
            
             value.addElement(new Categoria(rs.getInt("categoria_id"),rs.getString("categoria_nom")));
            
            }
            cn.close();
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Conexion erronea");
          
        }

    }
       
    public void addProdEstocLloc(Producto p, Lugar l, Stock s) {
        
        Conexion conecControl = new Conexion();
        Connection cn = conecControl.conectar();

        String sql = "INSERT INTO tbl_producte (prod_nom, prod_serie, categoria_id) VALUES (?,?,?)";
        String sql_lloc = "INSERT INTO tbl_lloc (num_bloc, num_passadis, num_lleixa) VALUES (?,?,?)";
        
//LR = last record       
        String sqlLRproducto = "SELECT DISTINCT last_insert_id() FROM tbl_producte";
        String sqlLRlloc = "SELECT DISTINCT last_insert_id() FROM tbl_lloc";
        
        String sqlEstoc = "INSERT INTO tbl_estoc (estoc_q_actual, estoc_q_min, estoc_q_max, prod_id, lloc_id) VALUES (?,?,?,?,?)";
        
        PreparedStatement pst1 = null;
        PreparedStatement pst2 = null;
        PreparedStatement pst3 = null;
        
        Statement st1 = null;
        Statement st2 = null;
        
        ResultSet rs = null;
        
        try {
            cn.setAutoCommit(false);

//insertar registros a la tbl_producte

            pst1 = cn.prepareStatement(sql);

            pst1.setString(1, p.getProd_nom());
            pst1.setString(2, p.getProd_serie());
            pst1.setInt(3, p.getCategoria_id());
            
            pst1.executeUpdate();
            //JOptionPane.showMessageDialog(null, "Producto");
            
//insertar registros a la tbl_lloc
            
            pst2 = cn.prepareStatement(sql_lloc);
            
            pst2.setString(1, l.getNum_bloc());
            pst2.setString(2, l.getNum_passadis());
            pst2.setString(3, l.getNum_lleixa());
            
            pst2.executeUpdate();
            //JOptionPane.showMessageDialog(null, "Lugar");
            
//obtener ultimos registros de la tbl_producte

            st1 = cn.createStatement();
            rs = st1.executeQuery(sqlLRproducto);
            int idst1=0;
            while(rs.next()){
            idst1=rs.getInt(1);
            }
            
//obtener ultimos registros de la tbl_lloc

            st2 = cn.createStatement();
            rs = st2.executeQuery(sqlLRlloc);
            int idst2=0;
            while(rs.next()){
            idst2=rs.getInt(1);
            }

//insertar registros a la tbl_estoc

            pst3 = cn.prepareStatement(sqlEstoc);
            
            pst3.setInt(1, s.getEstoc_q_actual());
            pst3.setInt(2, s.getEstoc_q_min());
            pst3.setInt(3, s.getEstoc_q_max());
            pst3.setInt(5, idst1);
            pst3.setInt(4, idst2);
              
            pst3.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registro añadido correctamente.");

            
            cn.commit();
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Conexion erronea");
            try {
                cn.rollback();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "No se puede deshacer");
            }          
        }
    }
    
    public void delProductoStockLugar(Stock es){
  
        Conexion conecControl = new Conexion();
        Connection cn = conecControl.conectar();
        
        String sql = "DELETE FROM tbl_estoc WHERE prod_id = ? ";
        String sql2 = "DELETE FROM tbl_producte WHERE prod_id = ?";
        String sql3 = "DELETE FROM tbl_lloc WHERE lloc_id = ?";
        
        PreparedStatement pst = null;
        PreparedStatement pst2 = null;
        PreparedStatement pst3 = null;
         
        try {
            cn.setAutoCommit(false);
            
            pst = cn.prepareStatement(sql);

            pst.setInt(1, es.getProd_id());
            
            pst.executeUpdate();
            
            /*if (n!=0){
            JOptionPane.showMessageDialog(null, "Borrado stock");
            }else{
            JOptionPane.showMessageDialog(null, "NO Borrado stock");
            }*/
           // 
            pst2 = cn.prepareStatement(sql2);
            
            pst2.setInt(1, es.getProd_id());
            
            pst2.executeUpdate();
            
            /*if (m!=0){
            JOptionPane.showMessageDialog(null, "Borrado producto");
            }else{
            JOptionPane.showMessageDialog(null, "NO Borrado producto");
            }*/
            //
            pst3 = cn.prepareStatement(sql3);
            
            pst3.setInt(1, es.getLloc_id());
            
            pst3.executeUpdate();
            
            /*if (o!=0){
            JOptionPane.showMessageDialog(null, "Borrado lloc");
            }else{
            JOptionPane.showMessageDialog(null, "NO Borrado lloc");
            }*/
            
            JOptionPane.showMessageDialog(null, "Se ha eliminado el registro.");
            
            cn.commit();
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Conexion erronea");
            try {
                cn.rollback();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "No se puede deshacer");
            }          
        }
    }
    
    public void modProductoStockLloc(Stock es, Producto p, Lugar l){
        
        Conexion conecControl = new Conexion();
        Connection cn = conecControl.conectar();
        
        String sql = "UPDATE tbl_producte SET prod_nom = ?, prod_serie = ?, categoria_id = ? WHERE prod_id = ?";
        String sql2 = "UPDATE tbl_lloc SET num_bloc = ?, num_passadis = ?, num_lleixa = ? WHERE lloc_id = ?";
        String sql3 = "UPDATE tbl_estoc SET estoc_q_actual = ?, estoc_q_min = ?, estoc_q_max = ? WHERE prod_id =?";
        
        PreparedStatement pst = null;
        PreparedStatement pst2 = null;
        PreparedStatement pst3 = null;
        
        try {
            cn.setAutoCommit(false);
        //    
            pst = cn.prepareStatement(sql);
            
            pst.setString(1, p.getProd_nom());
            pst.setString(2, p.getProd_serie());
            pst.setInt(3, p.getCategoria_id());
            pst.setInt(4, es.getProd_id());
            
            pst.executeUpdate();
            
            /*if (n!=0){
            JOptionPane.showMessageDialog(null, "cambiado producto");
            }else{
            JOptionPane.showMessageDialog(null, "no cmabiado prod");
            }*/
        //    
            pst2 = cn.prepareStatement(sql2);
            
            pst2.setString(1, l.getNum_bloc());
            pst2.setString(2, l.getNum_passadis());
            pst2.setString(3, l.getNum_lleixa());
            pst2.setInt(4, es.getLloc_id());
            
            pst2.executeUpdate();
            
            /*if (m!=0){
            JOptionPane.showMessageDialog(null, "cambiado lugar");
            }else{
            JOptionPane.showMessageDialog(null, "NO cambiado lugar");
            }*/
        //
            pst3 = cn.prepareStatement(sql3);
            
            pst3.setInt(1, es.getEstoc_q_actual());
            pst3.setInt(2, es.getEstoc_q_min());
            pst3.setInt(3, es.getEstoc_q_max());
            pst3.setInt(4, es.getProd_id());
            
            pst3.executeUpdate();
            
            /*if (o!=0){
            JOptionPane.showMessageDialog(null, "cambiado estoc");
            }else{
            JOptionPane.showMessageDialog(null, "no cambiado estoc");
            }*/
        //  
            JOptionPane.showMessageDialog(null, "Se ha modificado el registro.");    
        
            cn.commit();
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Conexion erronea");
            try {
                cn.rollback();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "No se puede deshacer");
            }          
        }
    }
    
    public DefaultTableModel buscar(String bus, int op){
        DefaultTableModel muestra = null;
        
        Conexion conecControl = new Conexion();
        Connection cn = conecControl.conectar();
        
        String vectorProducto[] = new String[13];
        String vectorProducto1[] = new String[13];
        
        vectorProducto1[0] = "ID";
        vectorProducto1[1] = "Nombre";
        vectorProducto1[2] = "Serie";
        vectorProducto1[3] = "Categoría";
        vectorProducto1[4] = "Stock";
        vectorProducto1[5] = "Stock MAX";
        vectorProducto1[6] = "Stock min";
        vectorProducto1[7] = "bloc";
        vectorProducto1[8] = "passadis";
        vectorProducto1[9] = "lleixa";
        vectorProducto1[10] = "estocid";
        vectorProducto1[11] = "llocid";
        vectorProducto1[12] = "catid";
          
        muestra = new DefaultTableModel(null,vectorProducto1);
        
        if (op == 0){
        
        String sql = "SELECT tbl_producte.prod_id, tbl_producte.prod_nom, tbl_producte.prod_serie, tbl_categoria.categoria_nom, tbl_estoc.estoc_q_actual, tbl_estoc.estoc_q_min, tbl_estoc.estoc_q_max, tbl_lloc.num_bloc, tbl_lloc.num_passadis, tbl_lloc.num_lleixa, tbl_estoc.estoc_id, tbl_lloc.lloc_id, tbl_producte.categoria_id FROM tbl_producte, tbl_categoria, tbl_estoc, tbl_lloc WHERE tbl_producte.categoria_id = tbl_categoria.categoria_id && tbl_estoc.prod_id = tbl_producte.prod_id && tbl_estoc.lloc_id = tbl_lloc.lloc_id && tbl_producte.prod_nom LIKE '%"+bus+"%'";        
        
        Statement st = null;
        ResultSet rs = null;
        
        
        //String[] vectorProducto; 
        try {
            
            st = cn.createStatement();
            rs = st.executeQuery(sql);
            
            while (rs.next()) {
                
                vectorProducto[0] = String.valueOf(rs.getInt("prod_id"));
                vectorProducto[1] = rs.getString("prod_nom");
                vectorProducto[2] = rs.getString("prod_serie");
                vectorProducto[3] = rs.getString("categoria_nom");
                vectorProducto[4] = String.valueOf(rs.getInt("estoc_q_actual"));
                vectorProducto[5] = String.valueOf(rs.getInt("estoc_q_max"));
                vectorProducto[6] = String.valueOf(rs.getInt("estoc_q_min"));
                vectorProducto[7] = rs.getString("num_bloc");
                vectorProducto[8] = rs.getString("num_passadis");
                vectorProducto[9] = rs.getString("num_lleixa");
                vectorProducto[10] = String.valueOf(rs.getInt("estoc_id"));
                vectorProducto[11] = String.valueOf(rs.getInt("lloc_id"));
                vectorProducto[12] = String.valueOf(rs.getInt("categoria_id"));
                
              muestra.addRow(vectorProducto);
            }
      
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "MARC.");   
        }
        
        return muestra;
        
        } else {
        
        String sql = "SELECT tbl_producte.prod_id, tbl_producte.prod_nom, tbl_producte.prod_serie, tbl_categoria.categoria_nom, tbl_estoc.estoc_q_actual, tbl_estoc.estoc_q_min, tbl_estoc.estoc_q_max, tbl_lloc.num_bloc, tbl_lloc.num_passadis, tbl_lloc.num_lleixa, tbl_estoc.estoc_id, tbl_lloc.lloc_id, tbl_producte.categoria_id FROM tbl_producte, tbl_categoria, tbl_estoc, tbl_lloc WHERE tbl_producte.categoria_id = tbl_categoria.categoria_id && tbl_estoc.prod_id = tbl_producte.prod_id && tbl_estoc.lloc_id = tbl_lloc.lloc_id && tbl_categoria.categoria_nom LIKE '%"+bus+"%'";        
        
        Statement st = null;
        ResultSet rs = null;
        
        
        //String[] vectorProducto; 
        try {
            
            st = cn.createStatement();
            rs = st.executeQuery(sql);
            
            while (rs.next()) {
                
                vectorProducto[0] = String.valueOf(rs.getInt("prod_id"));
                vectorProducto[1] = rs.getString("prod_nom");
                vectorProducto[2] = rs.getString("prod_serie");
                vectorProducto[3] = rs.getString("categoria_nom");
                vectorProducto[4] = String.valueOf(rs.getInt("estoc_q_actual"));
                vectorProducto[5] = String.valueOf(rs.getInt("estoc_q_max"));
                vectorProducto[6] = String.valueOf(rs.getInt("estoc_q_min"));
                vectorProducto[7] = rs.getString("num_bloc");
                vectorProducto[8] = rs.getString("num_passadis");
                vectorProducto[9] = rs.getString("num_lleixa");
                vectorProducto[10] = String.valueOf(rs.getInt("estoc_id"));
                vectorProducto[11] = String.valueOf(rs.getInt("lloc_id"));
                vectorProducto[12] = String.valueOf(rs.getInt("categoria_id"));
                
              muestra.addRow(vectorProducto);
            }
      
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "MARC.");   
        }
        
        return muestra;
        
        }
        
        
        
    }
    
    public DefaultTableModel buscarLoc(String bus, int op){
        DefaultTableModel muestraLoc = new DefaultTableModel();
        
        Conexion conecControl = new Conexion();
        Connection cn = conecControl.conectar();
        
        String vectorProducto[] = new String[5];
        String vectorProducto1[] = new String[5];
        
        vectorProducto1[0] = "ID";
        vectorProducto1[1] = "Nombre";
        vectorProducto1[2] = "Bloque";
        vectorProducto1[3] = "Pasadizo";
        vectorProducto1[4] = "Estantería";
          
        muestraLoc = new DefaultTableModel(null,vectorProducto1);
        
        if (op==0){
        String sql = "SELECT tbl_producte.prod_id, tbl_producte.prod_nom, tbl_lloc.num_bloc, tbl_lloc.num_passadis, tbl_lloc.num_lleixa FROM tbl_producte, tbl_estoc, tbl_lloc WHERE tbl_estoc.prod_id = tbl_producte.prod_id && tbl_estoc.lloc_id = tbl_lloc.lloc_id && tbl_producte.prod_nom LIKE '%"+bus+"%'";
        
        Statement st = null;
        ResultSet rs = null;
        
        
        //String[] vectorProducto; 
        try {
            
            st = cn.createStatement();
            rs = st.executeQuery(sql);
            
            while (rs.next()) {
                
                vectorProducto[0] = String.valueOf(rs.getInt("prod_id"));
                vectorProducto[1] = rs.getString("prod_nom");
                vectorProducto[2] = rs.getString("num_bloc");
                vectorProducto[3] = rs.getString("num_passadis");
                vectorProducto[4] = rs.getString("num_lleixa");
                
              muestraLoc.addRow(vectorProducto);
            }
      
        } catch (Exception e) {
        }
        
        return muestraLoc;
        
        }else {
        
        String sql = "SELECT tbl_producte.prod_id, tbl_producte.prod_nom, tbl_lloc.num_bloc, tbl_lloc.num_passadis, tbl_lloc.num_lleixa, tbl_categoria.categoria_nom FROM tbl_producte, tbl_estoc, tbl_lloc, tbl_categoria WHERE tbl_producte.categoria_id = tbl_categoria.categoria_id && tbl_estoc.prod_id = tbl_producte.prod_id && tbl_estoc.lloc_id = tbl_lloc.lloc_id && tbl_categoria.categoria_nom LIKE '%"+bus+"%'";
        
        Statement st = null;
        ResultSet rs = null;
        
        
        //String[] vectorProducto; 
        try {
            
            st = cn.createStatement();
            rs = st.executeQuery(sql);
            
            while (rs.next()) {
                
                vectorProducto[0] = String.valueOf(rs.getInt("prod_id"));
                vectorProducto[1] = rs.getString("prod_nom");
                vectorProducto[2] = rs.getString("num_bloc");
                vectorProducto[3] = rs.getString("num_passadis");
                vectorProducto[4] = rs.getString("num_lleixa");
                
              muestraLoc.addRow(vectorProducto);
            }
      
        } catch (Exception e) {
        }
        
        return muestraLoc;
        
        }
        
        
    }
}
